//
//  Initialisation
//  Mathematical Constants
//
//  Created by Niall Kehoe
//

import BookCore
import PlaygroundSupport
import SwiftUI
import Combine
import QuartzCore

let view = MathematicalConstants()
PlaygroundPage.current.setLiveView(view)
