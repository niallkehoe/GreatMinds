//
//  Initialisation
//  Turing
//
//  Created by Niall Kehoe
//

import UIKit
import BookCore
import PlaygroundSupport

PlaygroundPage.current.liveView = instantiateLiveView()
